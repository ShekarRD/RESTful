package com.training.boot.rest;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
//import org.springframework.boot.autoconfigure.security.oauth2.client.EnableOAuth2Sso;
import org.springframework.context.annotation.Bean;

import com.training.boot.rest.dao.CustomerDAO;
import com.training.boot.rest.domain.Customer;

@SpringBootApplication
//@EnableOAuth2Sso
public class SpringBootMs1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootMs1Application.class, args);
	}
	@Bean
	public CommandLineRunner loadInitialData(CustomerDAO dao) {
		return (args) -> {
			dao.save(new Customer("Satyen", "Singh", "MKG Steet", "Mumbai", "MH", "50050", "India"));
			dao.save(new Customer("Lion", "Singh", "MKG Steet", "Mumbai", "MH", "50050", "India"));
			dao.save(new Customer("Tiger", "Singh", "MKG Steet", "Mumbai", "MH", "50050", "India"));
			dao.save(new Customer("Elephant", "Singh", "MKG Steet", "Mumbai", "MH", "50050", "India"));
			dao.save(new Customer("Lion3", "Singh", "MKG Steet", "Mumbai", "MH", "50050", "India"));						
		};
	}
}
