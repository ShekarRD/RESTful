package com.training.boot.rest.swagger;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.google.common.base.Predicate;
import com.google.common.base.Predicates;

import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

//http://localhost:9090/swagger-ui.html
@Configuration
@EnableSwagger2
public class SwaggerConfig {
@Bean
public Docket customersApi() {
	return new Docket(DocumentationType.SWAGGER_2).groupName("public-api")
			.apiInfo(apiInfo()).select().paths(customerPaths()).build();
}

private Predicate<String> customerPaths() {
	return Predicates.or(PathSelectors.regex("/.*"),PathSelectors.regex("/.*"));
	
}

private ApiInfo apiInfo() {
	return new ApiInfoBuilder().title("Customer API").
			description("Customer Service API reference for developers").
			termsOfServiceUrl("http://boot.rest.training.com").version("1.0").build();
}
}
