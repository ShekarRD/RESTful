package com.training.boot.rest.resource;

import java.net.URI;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicInteger;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.Link;
import org.springframework.hateoas.Resources;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.training.boot.rest.dao.CustomerDAO;
import com.training.boot.rest.domain.Customer;

@SuppressWarnings("rawtypes")
@RestController
@RequestMapping("/customers")
public class CustomerResource {
 //private Map<Integer, Customer> customerDB = new HashMap<>();
 //private AtomicInteger idCounter= new AtomicInteger();
 
 @Autowired
 private CustomerDAO dao;
 
	/*
	 * public CustomerResource() { Customer customer = new Customer();
	 * customer.setId(idCounter.incrementAndGet()); customer.setFirstName("Shekar");
	 * customer.setLastName("Reddy"); customer.setStreet("Main st");
	 * customer.setCity("Hyd"); customer.setState("TS"); customer.setZip("1234");
	 * customer.setCountry("India"); customerDB.put(customer.getId(), customer); }
	 */
 
 @RequestMapping(value="{id}", produces= {"application/xml" , "application/json"}, method=RequestMethod.GET)
 public ResponseEntity<Customer> getCustomer(@PathVariable("id") Integer id) {
	 Optional<Customer> optional = dao.findById(id);
	 
	 if (!optional.isPresent()) {
		 return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
		 
	 }
	 return ResponseEntity.ok(optional.get());
 }
 
 @PostMapping(consumes= {"application/xml" , "application/json"})
 public ResponseEntity addNewCustomer(@RequestBody Customer customer) {
	  dao.save(customer);
	 return ResponseEntity.created(URI.create("/customers/"+customer.getId())).build();	 	 
 }
 
 @PutMapping(value="{id}", consumes = {"application/xml" , "application/json"})
 public ResponseEntity updateCustomer(@PathVariable("id") Integer id, @RequestBody Customer customer) {
	 Optional<Customer> optional = dao.findById(id);
	  if(!optional.isPresent()) {
		  return ResponseEntity.notFound().build();
	  }
	  //customer.setId(optional.get().getId());
	  customer.setId(id);
	  dao.save(customer);
	  return ResponseEntity.ok().build();
	 
 }
 
 @DeleteMapping(value="{id}")
 public ResponseEntity deleteCustomer(@PathVariable("id") Integer id) {
	 Optional<Customer> optional = dao.findById(id);
	 if(!optional.isPresent()) {
		  return ResponseEntity.notFound().build();
	  }
	 	dao.deleteById(id);
	 	 
	  return ResponseEntity.ok().build();
	 
 }
 
 @GetMapping(value="/customer/{start}/{count}", produces= {"application/xml" , "application/json"})
 public Resources<List<Customer>> getEmployeesByPage(@PathVariable("start") int start, 
		 @PathVariable("count") int count) {
	 List<Customer> tempemployee = dao.findAll();
	 List<Customer> employees = new ArrayList<>();
	 
	 start=start==0?1:start;
	 
	 System.out.println("Start = " + start);
	 System.out.println("Count = " + count);
	 
	 for(int i=0; i<count; i++) {
		 System.out.println("Retriving Customers");
		 employees.add(tempemployee.get(start+i));		 
	 }
	 System.out.println("returning = " + employees);
	 
	 Link nextLink = linkTo(methodOn(this.getClass()).getEmployeesByPage(start + count, count)).withRel("next");
	 Link prevLink = linkTo(methodOn(this.getClass()).getEmployeesByPage(start - count < 0?0:start-count, count)).withRel("previous");
	 
	 Resources resources;
	 
	 if(start == 1) {
		 resources = new Resources(employees, nextLink);
	 } else {
		 resources = new Resources(employees, nextLink, prevLink);
	 }
	 return resources;
 }
 
}
