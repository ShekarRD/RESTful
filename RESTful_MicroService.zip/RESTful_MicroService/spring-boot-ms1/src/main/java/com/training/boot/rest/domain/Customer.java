package com.training.boot.rest.domain;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.xml.bind.annotation.XmlRootElement;

//import org.springframework.boot.autoconfigure.security.oauth2.client.EnableOAuth2Sso;

@XmlRootElement
@Entity
public class Customer {
                @Id
                @GeneratedValue(strategy=GenerationType.AUTO)
                private Integer id;
                private String firstName;
                private String lastName;
                private String street;
                private String city;
                private String state;
                private String zip;
                private String country;  
                
                //For JPA
                public Customer() {
                	
                }
                
                public Customer(String firstName, String lastName, String street, String city, String state,
						String zip, String country) {
					super();
					this.firstName = firstName;
					this.lastName = lastName;
					this.street = street;
					this.city = city;
					this.state = state;
					this.zip = zip;
					this.country = country;		
				}
				
                public Integer getId() {
                                return id;
                }
                public void setId(Integer id) {
                                this.id = id;
                }
                
                
                public String getFirstName() {
                                return firstName;
                }
                public void setFirstName(String firstName) {
                                this.firstName = firstName;
                }
                
                
                public String getLastName() {
                                return lastName;
                }
                public void setLastName(String lastName) {
                                this.lastName = lastName;
                }
                
               
                public String getStreet() {
					return street;
				}
				public void setStreet(String street) {
					this.street = street;
				}
				
				
				public String getCity() {
					return city;
				}
				public void setCity(String city) {
					this.city = city;
				}
				
				
				public String getState() {
					return state;
				}
				public void setState(String state) {
					this.state = state;
				}
				
				
				public String getZip() {
					return zip;
				}
				public void setZip(String zip) {
					this.zip = zip;
				}
				
				
				public String getCountry() {
					return country;
				}
				public void setCountry(String country) {
					this.country = country;
				}                             
}
