package com.training.boot.rest.controller;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.Link;
import org.springframework.hateoas.Resources;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

import com.training.boot.rest.domain.Customer;

@Controller
public class CustomerWebsiteController {
	@Autowired
	private RestTemplate restTemplate;
	
	@RequestMapping("/home")
	public ModelAndView home() {
		ModelAndView modelAndView = new ModelAndView("home");
		modelAndView.addObject("customersURL","http://localhost:9080/customers/customer/1/2");
		return modelAndView;
	}
	
	@RequestMapping("customers/customer/{start}/{count}")
	public ModelAndView getCustomersByPage(@PathVariable("start") int start, @PathVariable("count") int count) {
		Resources resources = restTemplate.getForObject("http://localhost:9090/customers/customer/"+start+"/"+count, Resources.class);
	//http://localhost:9090/customers/customer/2/3
	ModelAndView modelAndView =new ModelAndView("customer");
	
	List<Link> links = resources.getLinks();
	List<Customer> customerList = new ArrayList<>();
	
	Collection<Map> customers = resources.getContent();
	for(Map customerMap : customers){
		int id = Integer.parseInt(customerMap.get("id").toString());
		String firstName = customerMap.get("firstName").toString();
		String lastName = customerMap.get("lastName").toString();
		Customer customer = new Customer(id, firstName, lastName);
		customerList.add(customer);		
	}
	
	modelAndView.addObject("customers", customerList);
	
	String stringURL1 = links.get(0).getHref();
	String stringURL2 = links.size()>1?links.get(1).getHref():null;
	System.out.println("Shekar     " + stringURL1);
	URL url1 =null, url2=null;
	
	try {
		url1 = new URL(stringURL1);
		url2 = stringURL2!=null? new URL(stringURL2):null;
		
		
	}catch (MalformedURLException e) {
		e.printStackTrace();
	}
	
	System.out.println("Shekar" + url1.getPath());
	modelAndView.addObject(links.get(0).getRel(), url1.getPath());
	
	if(url2!=null) {
		modelAndView.addObject(links.get(1).getRel(), url2.getPath());
	}
	
	return modelAndView;
	}
	
}
