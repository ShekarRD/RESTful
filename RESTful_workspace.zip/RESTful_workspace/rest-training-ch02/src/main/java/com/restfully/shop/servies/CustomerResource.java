package com.restfully.shop.servies;


import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.net.URI;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;


import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.NotFoundException;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.StreamingOutput;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.restfully.shop.domain.Address;
import com.restfully.shop.domain.Customer;

//@Path("/customers")
public class CustomerResource {
                private Map<Integer,Customer>customerDB= new ConcurrentHashMap<Integer,Customer>();
   private AtomicInteger idCounter= new AtomicInteger();
   
   public CustomerResource() {
        Customer customer = new Customer();
        customer.setId(idCounter.incrementAndGet());
        customer.setFirstName("Shekar");
        customer.setLastName("Reddy");
        
        Address address = new Address();
        address.setStreet("Main St");	
        address.setState("TS");
        address.setCity("Hyd");
        address.setCountry("India");
        address.setZip("500065");
        customer.setAddress(address);
        customerDB.put(customer.getId(), customer);
        
   }
   
   @POST
   @Consumes({"application/xml" , "application/json"})
   public Response createCustomer(Customer customer) {
	   customer.setId(idCounter.incrementAndGet());
	   customerDB.put(customer.getId(),customer);
	   System.out.println("Created customer"+customer.getId());
	   return Response.created(URI.create("/customers/" +customer.getId())).build();
   }
   
   @GET
   @Path("{id}")
   @Produces({"application/xml" , "application/json"})
   public Customer getCustomer(@PathParam("id")int id) {
   
        Customer customer =customerDB.get(id);
        if(customer == null) {
        	 //throw new CustomerNotFoundException("Customer not found" + id);
            //throw new WebApplicationException(Response.Status.NOT_FOUND);
            throw new NotFoundException("Customer not found" + id);
        }
        
        return customer;
   }
   
   @GET
   @Path("{first :[a-zA-Z]+}-[last:[a-zA-Z]+}")
   @Produces({"application/xml" , "application/json"})
   public StreamingOutput getCustomerFirstLast(@PathParam("first")String first,@PathParam("last") String last) {
                   Customer found=null;
                   for(Customer cust:customerDB.values()) {
                                   if(cust.getFirstName().equals(first)&&cust.getLastName().equals(last)){
                                                   found=cust;
                                                   break;
                                   }
                   }
                   if(found==null) {
                                   throw new WebApplicationException(Response.Status.NOT_FOUND);
                                   
                   }
                   final Customer customer= found;
                   return new StreamingOutput() {
                                   public void write(OutputStream outputStream) throws IOException,WebApplicationException{
                                                   outputCustomer(outputStream,customer);
                                   }
                   
                   };
                   }
    
   @PUT
   @Path("{id}")
   @Consumes({"application/xml" , "application/json"})
   public void updateCustomer(@PathParam("id")int id,Customer update) {
                   Customer current=customerDB.get(id);
                   if(current==null)
                                   throw new WebApplicationException(Response.Status.NOT_FOUND);
                   current.setFirstName(update.getFirstName());
                   current.setLastName(update.getLastName());
                   current.setAddress(update.getAddress());
   }
   
   
   protected void outputCustomer(OutputStream os, Customer cust) throws IOException {
                                PrintStream writer = new PrintStream(os);
                                writer.println("<customer id=\"" + cust.getId() + "\">");
                                writer.println("   <first-name>" + cust.getFirstName() + "</first-name>");
                                writer.println("   <last-name>" + cust.getLastName() + "</last-name>");
                                writer.println("</customer>");
                }


   
   protected Customer readCustomer(InputStream is) {
                                try {
                                                DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
                                                Document doc = builder.parse(is);
                                                Element root = doc.getDocumentElement();
                                                Customer cust = new Customer();
                                                if (root.getAttribute("id") != null && !root.getAttribute("id").trim().equals(""))
                                                                cust.setId(Integer.valueOf(root.getAttribute("id")));
                                                NodeList nodes = root.getChildNodes();
                                                for (int i = 0; i < nodes.getLength(); i++) {
                                                                Node element = (Node) nodes.item(i);
                                                                if (element.getNodeName().equals("first-name")) {
                                                                                cust.setFirstName(element.getTextContent());
                                                                } else if (element.getNodeName().equals("last-name")) {
                                                                                cust.setLastName(element.getTextContent());
                                                                }
                                                }
                                                return cust;
                                } catch (Exception e) {
                                                throw new WebApplicationException(e, Response.Status.BAD_REQUEST);
                                }
                }

}
