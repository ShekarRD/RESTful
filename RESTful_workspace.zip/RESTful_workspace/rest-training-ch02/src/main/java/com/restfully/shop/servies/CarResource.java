package com.restfully.shop.servies;

import javax.ws.rs.GET;
import javax.ws.rs.MatrixParam;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.PathSegment;
import javax.ws.rs.core.UriInfo;

@Path("/cars")
public class CarResource {
	
	public static enum Color {
		red, white, blue, black
	}
	
	 @GET
	 @Path("/matrix/{make}/{model}/{year}") // ..../services/cars/matrix/honda/city;color=red/2019
	 @Produces("text/plain")
	 public String getFromMatrixParams(@PathParam("make") String make, 
			 @PathParam("model") PathSegment car,
			 @MatrixParam("color") Color color,
			 @PathParam("year") String year) {
		   
	        return "A " + color + " "+ year +" "+ make + " " +car.getPath();
	 	}
	 
	 @GET
	 @Path("/uriinfo/{make}/{model}/{year}") // ..../services/cars/uriinfo/honda/city;color=red/2019
	 @Produces("text/plain")
	 public String getFromUriInfo(@Context UriInfo info) {
		   String make = info.getPathParameters().getFirst("make");
		   String year = info.getPathParameters().getFirst("year");
		   PathSegment model = info.getPathSegments().get(3);
		   String color = model.getMatrixParameters().getFirst("color");
		   
	        return "A " + color + " "+ year +" "+ make + " " +model.getPath();
	 	}
}
