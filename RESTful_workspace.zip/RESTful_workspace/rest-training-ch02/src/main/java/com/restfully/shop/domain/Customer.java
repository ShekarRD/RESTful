package com.restfully.shop.domain;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "customer")
public class Customer {
                
                private int id;
                private String firstName;
                private String lastName;
                private Address address;
                
                @XmlElement
                public Address getAddress() {
					return address;
				}
				public void setAddress(Address address) {
					this.address = address;
				}
				
				@XmlElement
                public int getId() {
                                return id;
                }
                public void setId(int id) {
                                this.id = id;
                }
                
                @XmlElement(name = "first-name")
                public String getFirstName() {
                                return firstName;
                }
                public void setFirstName(String firstName) {
                                this.firstName = firstName;
                }
                
                @XmlElement(name = "last-name")
                public String getLastName() {
                                return lastName;
                }
                public void setLastName(String lastName) {
                                this.lastName = lastName;
                }
                
}
