package com.restfully.shop.servies;


import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.net.URI;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;


import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.NotFoundException;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.CacheControl;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.EntityTag;
import javax.ws.rs.core.Link;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Request;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.StreamingOutput;
import javax.ws.rs.core.UriBuilder;
import javax.ws.rs.core.UriInfo;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.jboss.resteasy.annotations.providers.jaxb.Formatted;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.restfully.shop.domain.Address;
import com.restfully.shop.domain.Customer;
import com.restfully.shop.domain.Customers;

@Path("/customers")
public class CustomerResource {
                private Map<Integer,Customer>customerDB= new ConcurrentHashMap<Integer,Customer>();
   private AtomicInteger idCounter= new AtomicInteger();
   
   public CustomerResource() {
        Customer customer = new Customer();
        customer.setId(idCounter.incrementAndGet());
        customer.setFirstName("Shekar");
        customer.setLastName("Reddy");
        customer.setStreet("Main st");
        customer.setCity("Hyd");
        customer.setState("TS");
        customer.setZip("1234");
        customer.setCountry("India");
        customerDB.put(customer.getId(), customer);  
        
        Customer customerTwo = new Customer();
        customerTwo.setId(idCounter.incrementAndGet());
        customerTwo.setFirstName("Mani");
        customerTwo.setLastName("Reddy");
        customerTwo.setStreet("Main st");
        customerTwo.setCity("Hyd");
        customerTwo.setState("TS");
        customerTwo.setZip("1234");
        customerTwo.setCountry("India");            
        customerDB.put(customerTwo.getId(), customerTwo); 
        
        Customer customerThree = new Customer();
        customerThree.setId(idCounter.incrementAndGet());
        customerThree.setFirstName("Mani");
        customerThree.setLastName("Reddy");
        customerThree.setStreet("Main st");
        customerThree.setCity("Hyd");
        customerThree.setState("TS");
        customerThree.setZip("1234");
        customerThree.setCountry("India");            
        customerDB.put(customerThree.getId(), customerThree);
        
        Customer customerFour = new Customer();
        customerFour.setId(idCounter.incrementAndGet());
        customerFour.setFirstName("Mani");
        customerFour.setLastName("Reddy");
        customerFour.setStreet("Main st");
        customerFour.setCity("Hyd");
        customerFour.setState("TS");
        customerFour.setZip("1234");
        customerFour.setCountry("India");            
        customerDB.put(customerFour.getId(), customerFour);
   }
   
   @POST
   @Consumes({"application/xml" , "application/json"})
   public Response createCustomer(Customer customer) {
	   customer.setId(idCounter.incrementAndGet());
	   customerDB.put(customer.getId(),customer);
	   System.out.println("Created customer"+customer.getId());
	   return Response.created(URI.create("/customers/" +customer.getId())).build();
   }
   
   
	/*
	 * @GET
	 * 
	 * @Produces({"application/xml" , "application/json"}) public Customers
	 * getAllCustomerWithoutPaging() { List<Customer> list = new
	 * ArrayList<Customer>(); for(Customer customer : customerDB.values()) {
	 * list.add(customer); }
	 * 
	 * Customers customers = new Customers(); customers.setCustomers(list); return
	 * customers;
	 * 
	 * }
	 */

   @GET
   @Produces({"application/json" , "application/xml"})
   @Formatted
   public Customers getAllCustomerWithPaging(@QueryParam("start") int start, 
		   @QueryParam("size") @DefaultValue("2") int size,
		   @Context UriInfo uriInfo) {
	   UriBuilder builder = uriInfo.getAbsolutePathBuilder();
	   builder.queryParam("start", "{start}");
	   builder.queryParam("size", "{size}");
	   ArrayList<Customer> list = new  ArrayList<Customer>();
	   ArrayList<Link> links = new ArrayList<Link>();
	   synchronized (customerDB) {
		   int i = 0;
		   for(Customer customer : customerDB.values()) {
			   if(i >= start && i < start + size) 
				   list.add(customer);
				   i++;			   
		   }
		  
		   //next link
		   if(start + size < customerDB.size()) {
			   int next = start + size;
			   URI nextUri =builder.clone().build(next, size);
			   Link nextLink = Link.fromUri(nextUri).rel("next").type("application/xml").build();
			   links.add(nextLink);
		   }
		   
		   //Previous link
		   if(start > 0) {
			   int previous = start - size;
			   if(previous < 0)
				   previous = 0;
			   URI previousUri =builder.clone().build(previous, size);
			   Link previousLink = Link.fromUri(previousUri).rel("previous").type("application/xml").build();
			   links.add(previousLink);
		   }
	   }
	   
	   Customers customers = new Customers();
	   customers.setCustomers(list);
	   customers.setLinks(links);	   
	   return customers;	
}
  
   @GET
   @Path("{id}")
   @Produces({"application/xml" , "application/json"})
   public Response getCustomer(@PathParam("id")int id, @HeaderParam("If-None-Match") String sent,
		   @Context Request request) {
	   Customer cust =customerDB.get(id);
	   if(cust == null) 
		   throw new NotFoundException();
	   
        if(sent == null) 
        	 System.out.println("No If-None-Match sent by client");
        
       EntityTag tag = new EntityTag(Integer.toString(cust.hashCode()));
       System.out.println("Etag = " + tag);
       
       CacheControl cc = new CacheControl();
       cc.setMaxAge(5);
       
       Response.ResponseBuilder builder = request.evaluatePreconditions(tag);
       if(builder != null) {
    	   System.out.println("** revalidation on the server was sucessful, Dta didn't change...");
    	   //builder = Response.ok(cust , "application/xml");
    	   builder.cacheControl(cc);
    	   return builder.build();
       }
       //Preconditions not met
       System.out.println("** Data changed sending ned Data...");
       cust.setLastViewed(new Date().toString());
       //go and get the data from the DB
       builder = Response.ok(cust , "application/xml");
	   builder.cacheControl(cc);
	   builder.tag(tag);
	   return builder.build();
   }
   
//   @GET
//   @Path("{id}")
//   @Produces({"application/xml" , "application/json"})
//   public Customer getCustomer(@PathParam("id")int id) {
//   
//        Customer customer =customerDB.get(id);
//        if(customer == null) {
//        	 //throw new CustomerNotFoundException("Customer not found" + id);
//            //throw new WebApplicationException(Response.Status.NOT_FOUND);
//            throw new NotFoundException("Customer not found" + id);
//        }
//        
//        return customer;
//   }
    
	/*
	 * @PUT
	 * 
	 * @Path("{id}")
	 * 
	 * @Consumes({"application/xml" , "application/json"}) public void
	 * updateCustomer(@PathParam("id")int id,Customer update) { Customer
	 * current=customerDB.get(id); if(current==null) throw new
	 * WebApplicationException(Response.Status.NOT_FOUND);
	 * current.setFirstName(update.getFirstName());
	 * current.setLastName(update.getLastName()); }
	 */
   
   @PUT
   @Path("{id}")
   @Consumes({"application/xml" , "application/json"})
   public Response updateCustomer(@PathParam("id")int id, @Context Request request, Customer update) {
                   Customer cust=customerDB.get(id);
                   if(cust==null)
                         throw new WebApplicationException(Response.Status.NOT_FOUND);
                   EntityTag tag = new EntityTag(Integer.toString(cust.hashCode()));
                   System.out.println("Etag = " + tag);
                   
                   Response.ResponseBuilder builder = request.evaluatePreconditions(tag);
                   
                   if(builder != null) {
                	   //Preconditions not met
                	   return builder.build();              	   
                   }
                   
                   //Preconditions met, perform update -- This below code is normally is a database logic
                   
                   cust.setFirstName(update.getFirstName());
                   cust.setLastName(update.getLastName());
                   cust.setStreet(update.getStreet());
                   cust.setState(update.getState());
                   cust.setZip(update.getZip());
                   cust.setCountry(update.getCountry());
                   
                   builder = Response.noContent();
                   return builder.build();
                   
   }
}
