/*
 * package com.restfully.shop.servies;
 * 
 * import java.net.URI; import java.util.Map; import
 * java.util.concurrent.ConcurrentHashMap; import
 * java.util.concurrent.atomic.AtomicInteger;
 * 
 * import javax.ws.rs.Consumes; import javax.ws.rs.FormParam; import
 * javax.ws.rs.GET; import javax.ws.rs.HeaderParam; import javax.ws.rs.POST;
 * import javax.ws.rs.Path; import javax.ws.rs.PathParam; import
 * javax.ws.rs.Produces; import javax.ws.rs.QueryParam; import
 * javax.ws.rs.WebApplicationException; import javax.ws.rs.core.Response;
 * 
 * import com.restfully.shop.domain.Address; import
 * com.restfully.shop.domain.Customer;
 * 
 * //@Path("/customers") public class FirstLastCustomerResource { private
 * Map<Integer,Customer>customerDB= new ConcurrentHashMap<Integer,Customer>();
 * private AtomicInteger idCounter= new AtomicInteger();
 * 
 * public FirstLastCustomerResource() { Customer customer = new Customer();
 * customer.setId(idCounter.incrementAndGet()); customer.setFirstName("Shekar");
 * customer.setLastName("Reddy");
 * 
 * Address address = new Address(); address.setStreet("Main St");
 * address.setState("TS"); address.setCity("Hyd"); address.setCountry("India");
 * address.setZip("500065"); customer.setAddress(address);
 * customerDB.put(customer.getId(), customer);
 * 
 * }
 * 
 * @POST
 * 
 * @Consumes({"application/xml" , "application/json"}) public Response
 * createCustomer(Customer customer) {
 * customer.setId(idCounter.incrementAndGet());
 * customerDB.put(customer.getId(),customer);
 * System.out.println("Created customer"+customer.getId()); return
 * Response.created(URI.create("/customers/" +customer.getId())).build(); }
 * 
 * @GET
 * 
 * @Path("{id}")
 * 
 * @Produces({"application/xml" , "application/json"}) public Customer
 * getCustomer(@PathParam("id")int id ) {
 * 
 * Customer customer =customerDB.get(id); if(customer == null) { throw new
 * WebApplicationException(Response.Status.NOT_FOUND); }
 * 
 * return customer; }
 * 
 * @GET
 * 
 * @Path("/header")
 * 
 * @Produces({"application/xml" , "application/json"}) public String
 * getParams(@QueryParam("activate") String active, @FormParam("textName")
 * String name, @HeaderParam("User-Agent") String browser ) {
 * 
 * return active +"     "+ name +"     "+ browser; }
 * 
 * @POST
 * 
 * @Path("/form")
 * 
 * @Produces("text/plain") public String getFormParams(@FormParam("textName")
 * String name ) {
 * 
 * return name; } }
 */